from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager
from typing import List
import os
import sys

# Adiciona o diretório atual ao path para imports
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

try:
    # Tenta importar do diretório src
    from src.models.corrida_model import Corrida
    from src.producer import broker, publish_corrida
    from src.database.mongo_client import MongoDB
    from src.database.redis_client import RedisClient
    # Importa o consumidor para garantir que os subscribers sejam registrados no broker
    import src.consumer 
    print("Todos os imports realizados com sucesso")
except ImportError as e:
    print(f"Erro de importação: {e}")
    print("Diretório atual:", os.getcwd())
    print("Arquivos no diretório:", os.listdir('.'))
    if os.path.exists('src'):
        print("Arquivos em src:", os.listdir('src'))
    raise

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Inicialização
    try:
        MongoDB.get_client()
        await RedisClient.get_client()
        await broker.start()
        print("Todos os serviços inicializados com sucesso")
    except Exception as e:
        print(f"Erro na inicialização: {e}")
        raise
    
    yield
    
    # Encerramento
    try:
        await broker.close()
        MongoDB.close()
        await RedisClient.close()
        print("Todos os serviços finalizados com sucesso")
    except Exception as e:
        print(f"Erro no encerramento: {e}")

app = FastAPI(
    title="TransFlow API",
    description="Backend assíncrono para corridas urbanas",
    version="1.0.0",
    lifespan=lifespan
)

# --- Rotas ---

@app.get("/")
async def root():
    return {"message": "TransFlow API está rodando!"}

@app.post("/corridas", status_code=202)
async def cadastrar_corrida(corrida: Corrida):
    """
    Recebe uma nova corrida e publica para processamento assíncrono.
    """
    try:
        # Pydantic v2 - use model_dump()
        corrida_data = corrida.model_dump()
        
        # Publica no RabbitMQ através do FastStream
        await publish_corrida(corrida_data)
        return {
            "status": "processando", 
            "mensagem": "Corrida enviada para fila de processamento", 
            "id": corrida.id_corrida
        }
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Erro ao processar corrida: {str(e)}"
        )

@app.get("/corridas", response_model=List[Corrida])
async def listar_corridas():
    """
    Lista todas as corridas armazenadas no MongoDB.
    """
    try:
        db = MongoDB.get_db()
        corridas = await db["corridas"].find().to_list(length=100)
        
        # Converte ObjectId para string se necessário
        for corrida in corridas:
            if '_id' in corrida:
                corrida['id_corrida'] = str(corrida['_id'])
                del corrida['_id']
        
        return corridas
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Erro ao buscar corridas: {str(e)}"
        )

@app.get("/corridas/pagamento/{forma_pagamento}", response_model=List[Corrida])
async def filtrar_corridas_pagamento(forma_pagamento: str):
    """
    Filtra corridas por tipo de pagamento.
    """
    try:
        db = MongoDB.get_db()
        corridas = await db["corridas"].find({"forma_pagamento": forma_pagamento}).to_list(length=100)
        
        if not corridas:
            raise HTTPException(
                status_code=404, 
                detail=f"Nenhuma corrida encontrada com forma de pagamento: {forma_pagamento}"
            )
        
        # Converte ObjectId para string se necessário
        for corrida in corridas:
            if '_id' in corrida:
                corrida['id_corrida'] = str(corrida['_id'])
                del corrida['_id']
            
        return corridas
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Erro ao filtrar corridas: {str(e)}"
        )

@app.get("/saldo/{motorista}")
async def consultar_saldo(motorista: str):
    """
    Consulta o saldo atual do motorista no Redis.
    """
    try:
        redis = await RedisClient.get_client()
        chave_saldo = f"saldo:{motorista.lower()}"
        
        saldo = await redis.get(chave_saldo)
        
        if saldo is None:
            return {"motorista": motorista, "saldo": 0.0}
        
        return {"motorista": motorista, "saldo": float(saldo)}
    
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Erro ao consultar saldo: {str(e)}"
        )

# Para executar diretamente
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=True)