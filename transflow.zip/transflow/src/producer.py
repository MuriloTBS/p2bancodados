from faststream.rabbit import RabbitBroker
import os

# Configura o broker (RabbitMQ)
# Se não houver variável de ambiente, tenta conectar no localhost padrão
rabbit_url = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")
broker = RabbitBroker(rabbit_url)

# Definição da fila
QUEUE_NAME = "corridas_queue"

async def publish_corrida(dados_corrida: dict):
    """
    Publica os dados da corrida na fila do RabbitMQ.
    """
    await broker.publish(
        message=dados_corrida,
        queue=QUEUE_NAME
    )
    # Log para vermos acontecer no terminal
    print(f" [x] Corrida enviada para fila: {dados_corrida.get('id_corrida')}")