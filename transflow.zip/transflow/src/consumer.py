from src.producer import broker
from src.models.corrida_model import Corrida
from src.database.mongo_client import MongoDB
from src.database.redis_client import RedisClient

# O decorator @broker.subscriber regista esta função para ouvir a fila
@broker.subscriber("corridas_queue", exchange="transflow_exchange")
async def processar_corrida(corrida: Corrida):
    """
    Consome eventos de corrida, salva no Mongo e atualiza saldo no Redis.
    """
    try:
        print(f"Processando corrida: {corrida.id_corrida}")
        
        # 1. Atualizar Saldo no Redis
        redis = RedisClient.get_client()
        
        # CORREÇÃO: Acessar o motorista corretamente
        # Se motorista for uma string simples
        if hasattr(corrida.motorista, 'nome'):
            nome_motorista = corrida.motorista.nome
        else:
            nome_motorista = str(corrida.motorista)
        
        chave_saldo = f"saldo:{nome_motorista.lower()}"
        
        # CORREÇÃO: Usar método correto do Redis e atributo correto
        # Verificar qual atributo contém o valor da corrida
        if hasattr(corrida, 'valor_corrida'):
            valor = corrida.valor_corrida
        elif hasattr(corrida, 'valor'):
            valor = corrida.valor
        else:
            # Fallback - tentar encontrar algum atributo de valor
            valor = 0.0
            for attr in ['valor', 'preco', 'amount', 'value']:
                if hasattr(corrida, attr):
                    valor = getattr(corrida, attr)
                    break
        
        # CORREÇÃO: Usar método correto do Redis
        # Se incrbyfloat não existir, usar approach alternativo
        saldo_atual = await redis.get(chave_saldo)
        saldo_atual = float(saldo_atual) if saldo_atual else 0.0
        novo_saldo = saldo_atual + valor
        await redis.set(chave_saldo, str(novo_saldo))
        
        print(f"Saldo atualizado para {nome_motorista}: {novo_saldo}")

        # 2. Persistir no MongoDB
        db = MongoDB.get_db()
        collection = db["corridas"]
        
        # Converte para dict para salvar no Mongo
        documento = corrida.model_dump()
        
        # Upsert: Atualiza se existir, cria se não existir
        await collection.update_one(
            {"id_corrida": corrida.id_corrida},
            {"$set": documento},
            upsert=True
        )
        print(f"Corrida salva no MongoDB.")
        
    except Exception as e:
        print(f"Erro ao processar corrida {corrida.id_corrida}: {e}")