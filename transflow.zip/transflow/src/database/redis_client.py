import redis.asyncio as redis
import os

class RedisClient:
    client = None

    @classmethod
    async def get_client(cls):
        if cls.client is None:
            redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
            # decode_responses=True faz com que o Redis retorne strings em vez de bytes
            cls.client = redis.from_url(redis_url, decode_responses=True)
            print(f"Conectado ao Redis: {redis_url}")
        return cls.client

    @classmethod
    async def close(cls):
        if cls.client:
            await cls.client.close()
            cls.client = None
            print("Conexão com Redis fechada.")