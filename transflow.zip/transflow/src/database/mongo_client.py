import os
import logging
from motor.motor_asyncio import AsyncIOMotorClient

# Configuração básica de logs para veres o que acontece no terminal
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MongoDB:
    client: AsyncIOMotorClient = None
    # Permite mudar o nome do banco via variável de ambiente ou usa o padrão
    db_name = os.getenv("MONGO_DB_NAME", "transflow_db")

    @classmethod
    def get_client(cls):
        """
        Cria ou recupera a conexão com o MongoDB.
        """
        if cls.client is None:
            # Pega a URL do ambiente ou usa localhost como padrão
            mongo_url = os.getenv("MONGO_URL", "mongodb://localhost:27017")
            
            try:
                cls.client = AsyncIOMotorClient(mongo_url)
                logger.info(f"Cliente MongoDB inicializado: {mongo_url}")
            except Exception as e:
                logger.error(f"Erro ao conectar ao MongoDB: {e}")
                raise e
        
        return cls.client

    @classmethod
    def get_db(cls):
        """
        Retorna a instância específica do banco de dados.
        """
        if cls.client is None:
            cls.get_client()
        return cls.client[cls.db_name]

    @classmethod
    def close(cls):
        """
        Fecha a conexão com o banco de dados.
        """
        if cls.client:
            cls.client.close()
            cls.client = None
            logger.info("Conexão com MongoDB fechada.")